#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun  2 09:11:29 2018

@author: Infuny
"""

__author__ = 'Infuny'

configs = {
        'db' : {
                'user' : 'Infuny',
                'password' : 'asdfgh',
                'host' : 'localhost',
                'database' : 'puresakura'
                }
        }